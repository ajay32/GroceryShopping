package app.infiniverse.grocery;

/**
 * Created by chintu gandhwani on 1/22/2018.
 */

public interface AddorRemoveCallbacks {

    public void onAddProduct();
    public void onRemoveProduct();
}
