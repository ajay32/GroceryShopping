package app.infiniverse.grocery;

/**
 * Created by root on 25/3/18.
 */

public class GridItem {
    private String image;
    private String title;

    public GridItem() {
        super();
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
